import numpy as np
from pysnptools.snpreader import Bed
import pandas as pd
import datetime
import os

from balance_longwas_emai import *
from balance_predata import *


def balance_longwas_fixreg(data_file, id, tpoint, trait, kin_file, bed_file, var_com, snp_lst=None, tfix=None, fix=None,
            forder=3, rorder=3, na_method='omit', maxiter=10, cc_par=1.0e-6, cc_gra=1000000.0, em_weight_step=0.01,
                           prefix_outfile='gma_balance_longwas_fixreg'):
    # os.chdir(os.path.dirname(os.path.abspath(data_file)))
    logfile = prefix_outfile + '.log'
    logfile_out = open(logfile, "w")
    s = '################################'
    print s
    logfile_out.write(s + '\n')
    s = '###Prepare the related matrix###'
    print s
    logfile_out.write(s + '\n')
    s = '################################'
    print s
    logfile_out.write(s + '\n')
    
    starttime = datetime.datetime.now()
    if var_com.shape[0] != rorder*(rorder + 1) + 2*(rorder+1) + 1:
        print 'Variances do not match the data, please check'
        exit()
    y, xmat_t, leg_tp, leg_fix, id_in_data_lst, kin_eigen_val, kin_eigen_vec = balance_predata(data_file, id, tpoint,
                trait, kin_file, logfile_out, tfix=tfix, fix=fix, forder=forder, rorder=rorder, na_method=na_method)
    snp_on_disk = Bed(bed_file, count_A1=False)
    if len(set(id_in_data_lst) - set(snp_on_disk.iid[:, -1])) != 0:
        print set(id_in_data_lst) - set(snp_on_disk.iid[:, -1]), 'in the data file is not in the snp file!'
        exit()
    # snp list
    if snp_lst is None:
        snp_lst = range(snp_on_disk.sid_count)
    else:
        try:
            snp_lst = np.array(snp_lst, dtype=int)
        except Exception, e:
            print e
            print 'The snp list value should be int'
            exit()
    snp_lst = list(snp_lst)
    if min(snp_lst) < 0 or max(snp_lst) >= snp_on_disk.sid_count:
        print 'The value in the snp list should be >=', 0, 'and <', snp_on_disk.sid_count
        exit()
    
    id_in_data_index = []
    for i in id_in_data_lst:
        id_in_data_index.append(list(snp_on_disk.iid[:, -1]).index(i))
    snp_data = snp_on_disk[id_in_data_index, snp_lst].read().val
    endtime = datetime.datetime.now()
    s = "Running time: " + str((endtime - starttime).seconds) + ' seconds'
    print s
    logfile_out.write(s + '\n')
    
    s = '###################################################################'
    print s
    logfile_out.write(s + '\n')
    s = '###Start the fixed regression longitudinal GWAS for balance data###'
    print s
    logfile_out.write(s + '\n')
    s = '###################################################################'
    print s
    logfile_out.write(s + '\n')
    starttime = datetime.datetime.now()
    cc_par_vec = []
    cc_gra_vec = []
    eff_vec = []
    chi_vec = []
    p_vec = []
    for i in range(snp_data.shape[1]):
        snp_fix = np.multiply(leg_fix, snp_data[:, i].reshape(1, snp_on_disk.iid_count, 1))
        snp_fix = np.matmul(np.array([kin_eigen_vec.T]), snp_fix)
        snp_fix = snp_fix.transpose(1, 2, 0)
        snp_fix = np.concatenate((xmat_t, snp_fix), axis=2)
        res1 = balance_longwas_emai(y, snp_fix, leg_tp, kin_eigen_val, init=var_com['var_val'],
                                    maxiter=maxiter, cc_par=cc_par, cc_gra=cc_gra, em_weight_step=em_weight_step)
        cc_par_vec.append(res1[0])
        cc_gra_vec.append(res1[1])
        eff_vec.append(res1[2])
        chi_vec.append(res1[3])
        p_vec.append((res1[4]))
    endtime = datetime.datetime.now()
    s = "Running time: " + str((endtime - starttime).seconds) + ' seconds'
    print s
    logfile_out.write(s + '\n')
    s = 'Finish association analysis'
    print s
    logfile_out.write(s + '\n')
    
    s = '***Output***'
    print s
    logfile_out.write(s + '\n')
    snp_info_file = bed_file + '.bim'
    snp_info = pd.read_csv(snp_info_file, sep='\s+', header=None)
    res_df = snp_info.iloc[snp_lst, [0, 1, 3, 4, 5]]
    res_df.columns = ['chro', 'snp_ID', 'pos', 'allele1', 'allele2']
    res_df.loc[:, 'order'] = snp_lst
    res_df = res_df.iloc[:, [5, 0, 1, 2, 3, 4]]
    res_df.loc[:, 'cc_par_val'] = cc_par_vec
    res_df.loc[:, 'cc_gra_val'] = cc_gra_vec
    eff_vec = np.array(eff_vec)
    for i in range(eff_vec.shape[1]):
        col_ind = 'eff' + str(i)
        res_df.loc[:, col_ind] = eff_vec[:, i]
    res_df.loc[:, 'chi_val'] = chi_vec
    res_df.loc[:, 'p_val'] = p_vec
    
    out_file = prefix_outfile + '.res'
    try:
        res_df.to_csv(out_file, sep=' ', index=False)
    except Exception, e:
        print e
        print 'Fail to output the result!'
        exit()
    
    return res_df
