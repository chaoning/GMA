import numpy as np
from pysnptools.snpreader import Bed
import pandas as pd
import datetime
import math


def cal_kin(bed_file, inv=True, small_val=0.001):
    print "Read the SNP data."
    start_time = datetime.datetime.now()
    snp_on_disk = Bed(bed_file, count_A1=False)
    snp_mat = snp_on_disk.read().val
    end_time = datetime.datetime.now()
    print "Running time:", (end_time - start_time).seconds, 'seconds'
    
    print 'Calculate the SNP frequency.'
    start_time = datetime.datetime.now()
    freq = np.sum(snp_mat, axis=0) / (2 * snp_on_disk.iid_count)
    freq.shape = (1, snp_on_disk.sid_count)
    scale = 2 * freq * (1 - freq)
    scale = np.sum(scale)
    if math.isnan(scale):
        print 'Missing genotypes are not allowed!!!'
        exit()
    
    print 'Centralize the SNP data'
    snp_mat = snp_mat - 2*freq
    end_time = datetime.datetime.now()
    print "Running time:", (end_time - start_time).seconds, 'seconds'
    
    print 'Calculate the kinship'
    start_time = datetime.datetime.now()
    kin = np.dot(snp_mat, snp_mat.T)/scale
    kin_diag = np.diag(kin)
    kin_diag = kin_diag + kin_diag * small_val
    np.fill_diagonal(kin, kin_diag)
    end_time = datetime.datetime.now()
    print "Running time:", (end_time - start_time).seconds, 'seconds'
    
    print 'Output the kinship'
    start_time = datetime.datetime.now()
    ind = np.tril_indices_from(kin)
    val = kin[ind]
    id1 = snp_on_disk.iid[:, 1][ind[0]]
    id2 = snp_on_disk.iid[:, 1][ind[1]]
    data_df = {'id1': id1, 'id2': id2, 'val': val}
    data_df = pd.DataFrame(data_df, columns=['id1', 'id2', 'val'])
    kin_file = bed_file + '.grm'
    data_df.to_csv(kin_file, sep=' ', header=False, index=False)
    end_time = datetime.datetime.now()
    print "Running time:", (end_time - start_time).seconds, 'seconds'
    
    kin_inv = None
    if inv:
        print 'Calculate the inversion of kinship'
        start_time = datetime.datetime.now()
        kin_inv = np.linalg.inv(kin)
        end_time = datetime.datetime.now()
        print "Running time:", (end_time - start_time).seconds, 'seconds'
        
        print 'Output the inversion'
        start_time = datetime.datetime.now()
        val = kin_inv[ind]
        data_df = {'id1': id1, 'id2': id2, 'val': val}
        data_df = pd.DataFrame(data_df, columns=['id1', 'id2', 'val'])
        kin_inv_file = bed_file + '.giv'
        data_df.to_csv(kin_inv_file, sep=' ', header=False, index=False)
        end_time = datetime.datetime.now()
        print "Running time:", (end_time - start_time).seconds, 'seconds'
    
    return [kin, kin_inv]
