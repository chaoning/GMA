import math
import numpy as np
import pandas as pd
from scipy import linalg
from scipy import sparse
from scipy.sparse import csr_matrix, isspmatrix, hstack, vstack
import datetime

from common import *
from pre_mat import *
from iter_mat import *


def unbalance_emai(y, xmat, zmat, kin, logfile_out, fixcon=False, rancon=False, init=None, maxiter=30, cc_par=1.0e-8,
                   cc_gra=1.0e-6, cc_ll=0.001, em_weight_step=0.02):
    num_var_pos = 1
    for i in range(len(zmat)):
        num_var_pos += len(zmat[i])
    y_var = np.var(y)/num_var_pos
    num_record = y.shape[0]
    var_com = []
    eff_ind = [[0, xmat.shape[1]]]  # the index for all effects [start end]
    zmat_con_lst = []  # combined random matrix
    cov_dim = []  # the dim for covariance matrix
    vari = []
    varij = []
    varik = []
    for i in range(len(zmat)):
        temp = [eff_ind[i][-1]]
        zmat_con_lst.append(hstack(zmat[i]))
        cov_dim.append(len(zmat[i]))
        for j in range(len(zmat[i])):
            temp.append(temp[-1] + zmat[i][j].shape[1])
            for k in range(j + 1):
                vari.append(i+1)
                varij.append(j+1)
                varik.append(k+1)
                if j == k:
                    var_com.append(y_var)
                else:
                    var_com.append(0.0)
        eff_ind.append(temp)
    var_com.append(y_var)
    vari.append(i + 2)
    varij.append(1)
    varik.append(1)
    if init is None:
        var_com = np.array(var_com)
    else:
        if len(var_com) != len(init):
            print 'The length of initial variances should be', len(var_com)
            exit()
        else:
            var_com = np.array(init)
    var_com_em = var_com.copy()
    
    s = '***prepare the MME**'
    print s
    logfile_out.write(s + '\n')
    zmat_con = hstack(zmat_con_lst)  # design matrix for random effects
    wmat = hstack([xmat, zmat_con])  # merged design matrix
    cmat_pure = np.dot(wmat.T, wmat)  # C matrix
    rhs_pure = wmat.T.dot(y)  # right hand
    
    # em weight vector
    if em_weight_step <= 0.0 or em_weight_step > 1.0:
        print 'The em weight step should be between 0 (not include) and 1 (include)'
        exit()
    iter_count = 0
    em2ai_iter_count = 0
    em_inter_count = 0
    cc_par_val = 1000.0
    cc_gra_val = 1000.0
    ll_val = 1000.0
    cc_ll_val = 1000.0
    ll_val_pre = 1.0e30
    s = "initial variances: " + ' '.join(np.array(var_com, dtype=str))
    print s
    logfile_out.write(s + '\n')
    starttime = datetime.datetime.now()
    covi_mat = pre_covi_mat(cov_dim, var_com)
    if covi_mat is None:
        print "Initial variances is not positive define, please check!"
        exit()
    cmati, eff, e = pre_mat(y, xmat, eff_ind, zmat_con, cov_dim, var_com, covi_mat, cmat_pure, kin, rhs_pure)
    while iter_count < maxiter:
        iter_count += 1
        em2ai_iter_count += 1
        s = '***Start the iteration: ' + str(iter_count) + ' ***'
        print s
        logfile_out.write(s + '\n')
        # first-order derivative
        fd_mat = pre_fd_mat_x(cmati, kin, covi_mat, eff, eff_ind, e, cov_dim, zmat_con_lst, wmat, num_record, var_com)
        # AI matrix
        ai_mat = pre_ai_mat(cmati, covi_mat, eff, eff_ind, e, cov_dim, zmat_con_lst, wmat, var_com)
        delta = np.dot(linalg.inv(ai_mat), fd_mat)
        var_com_update = var_com + delta
        covi_mat = pre_covi_mat(cov_dim, var_com_update)
        
        if covi_mat is None:  # AI fail, to combined em ai
            em_inter_count += 1
            s = 'This is EM iteration: ' + str(em_inter_count)
            print s
            logfile_out.write(s + '\n')
            covi_mat = pre_covi_mat(cov_dim, var_com_em)  # update the inversion of variances with the nearest em
            if em2ai_iter_count != 1:  # update the related matrix with the nearest em
                cmati, eff, e = pre_mat(y, xmat, eff_ind, zmat_con, cov_dim, var_com_em, covi_mat, cmat_pure, kin,
                                        rhs_pure)
                fd_mat = pre_fd_mat_x(cmati, kin, covi_mat, eff, eff_ind, e, cov_dim, zmat_con_lst, wmat, num_record,
                                    var_com_em)
                ai_mat = pre_ai_mat(cmati, covi_mat, eff, eff_ind, e, cov_dim, zmat_con_lst, wmat, var_com_em)
            # EM matrix
            em_mat = pre_em_mat(cov_dim, zmat_con_lst, num_record, var_com_em)
            em2ai_iter_count = 0
            
            # Increase em weight to guarantee variances positive
            gamma = 0.0
            while gamma < 1.0:
                gamma = gamma + em_weight_step
                if gamma >= 1.0:
                    gamma = 1.0
                wemai_mat = (1 - gamma)*ai_mat + gamma*em_mat
                delta = np.dot(linalg.inv(wemai_mat), fd_mat)
                var_com_update = var_com + delta
                covi_mat = pre_covi_mat(cov_dim, var_com_update)
                if covi_mat is not None:
                    s = 'EM weight value: ' + str(gamma)
                    print s
                    logfile_out.write(s + '\n')
                    break
            var_com_em = var_com_update.copy()
        
        s = 'Updated variances: ' + ' '.join(np.array(var_com_update, dtype=str))
        print s
        logfile_out.write(s + '\n')
        if covi_mat is None:
            print "Updated variances is not positive define!"
            exit()
        
        cmati, eff, e = pre_mat(y, xmat, eff_ind, zmat_con, cov_dim, var_com_update, covi_mat, cmat_pure, kin, rhs_pure)
        
        # Convergence criteria
        cc_par_val = np.sum(pow(delta, 2)) / np.sum(pow(var_com_update, 2))
        cc_par_val = np.sqrt(cc_par_val)
        cc_gra_val = np.sqrt(np.sum(pow(fd_mat, 2)))
        var_com = var_com_update.copy()
        s = "Change in parameters, Norm of gradient vector: " + str(cc_par_val) + ', ' + str(cc_gra_val)
        print s
        logfile_out.write(s + '\n')
        
        # Log likelihood function value
        yry = np.divide(np.dot(y.T, y), var_com[-1])
        left = np.divide(wmat.T.dot(y), var_com[-1])
        eff_y = np.dot(cmati, left)
        ypy = np.sum(yry - np.dot(left.T, eff_y))
        det_c = -np.linalg.slogdet(cmati)[1]
        det_r = num_record * np.log(var_com[-1])
        det_g = 0.0
        for i in range(len(cov_dim)):
            if isspmatrix(kin[i]):
                det_g += -kin[i].shape[1] * np.linalg.slogdet(covi_mat[i])[1]
            else:
                det_g += -kin[i].shape[1] * np.linalg.slogdet(covi_mat[i])[1]
        ll_val = det_r + det_g + det_c + ypy
        s = "-2logL: " + str(ll_val)
        print s
        logfile_out.write(s + '\n')
        cc_ll_val = abs(ll_val_pre - ll_val)
        ll_val_pre = ll_val
        if cc_par_val < cc_par and cc_gra_val < cc_gra and cc_ll_val < cc_ll:
            break
    
    endtime = datetime.datetime.now()
    s = "Running time: " + str((endtime - starttime).seconds) + ' seconds'
    print s
    logfile_out.write(s + '\n')
    
    if cc_par_val < cc_par and cc_gra_val < cc_gra and cc_ll_val < cc_ll:
        convergence = True
        s = "Variances Converged"
        print s
        logfile_out.write(s + '\n')
    else:
        convergence = False
        s = "Variances not Converged"
        print s
        logfile_out.write(s + '\n')
    
    # add
    fixcon_val = 0.0
    rancon_val = 0.0
    if fixcon:
        temp = xmat.T.dot(xmat)
        fixcon_val += -np.linalg.slogdet(temp.toarray())[1]
    if rancon:
        for i in range(len(cov_dim)):
            if not isspmatrix(kin[i]):
                rancon_val += -cov_dim[i] * np.linalg.slogdet(kin[i])[1]
    ll_val = ll_val + fixcon_val + rancon_val
    aic_val = 2.0*len(var_com) + ll_val
    s = "AIC value: " + str(aic_val)
    print s
    logfile_out.write(s + '\n')
    bic_val = len(var_com)*math.log(num_record) + ll_val
    s = "BIC value: " + str(bic_val)
    print s
    logfile_out.write(s + '\n')
    var_pd = {'vari': vari,
              "varij": varij,
              "varik": varik,
              "var_val": var_com}
    var_pd = pd.DataFrame(var_pd, columns=['vari', "varij", "varik", "var_val"])
    res = {'variances': var_pd,
           'cc_par': cc_par_val,
           'cc_gra': cc_par_val,
           'convergence': convergence,
           'll': ll_val,
           'effect': eff,
           'CMi': cmati,
           'AIC': aic_val,
           'BIC': bic_val}
    return res
