from scipy.sparse import csr_matrix, hstack
import numpy as np
import pandas as pd
from patsy import dmatrix
from pysnptools.snpreader import Bed
import datetime
from scipy.stats import chi2
import gc
import os

from common import *

def unbalance_longwas_lm(data_file, id, tpoint, trait, bed_file, snp_lst=None, tfix=None, fix=None, forder=3,
                         na_method='omit', prefix_outfile='gma_unbalance_longwas_lm'):
    # os.chdir(os.path.dirname(os.path.abspath(data_file)))
    logfile = prefix_outfile + '.log'
    logfile_out = open(logfile, "w")
    s = '#########################################'
    print s
    logfile_out.write(s + '\n')
    s = '###Start balanced longitudinal lm GWAS###'
    print s
    logfile_out.write(s + '\n')
    s = '#########################################'
    print s
    logfile_out.write(s + '\n')
    starttime = datetime.datetime.now()
    
    s = '***Read the data file***'
    print s
    logfile_out.write(s + '\n')
    s = 'Data file: ' + data_file
    print s
    logfile_out.write(s + '\n')
    try:
        data_df = pd.read_csv(data_file, sep='\s+', header=0)
    except Exception, e:
        print e
        print "Fail to open the data file."
        exit()
    
    s = 'NA method: ' + na_method
    print s
    logfile_out.write(s + '\n')
    if na_method == 'omit':
        data_df = data_df.dropna()
    elif na_method == 'include':
        data_df = data_df.fillna(method='ffill')
        data_df = data_df.fillna(method='bfill')
    else:
        print 'na_method does not exist', na_method
        exit()
    
    col_names = data_df.columns
    s = 'The column names of data file: ' + ' '.join(list(col_names))
    print s
    logfile_out.write(s + '\n')
    s = 'Note: Variates beginning with a capital letter is converted into factors.'
    print s
    logfile_out.write(s + '\n')
    class_vec = []
    for val in col_names:
        if not val[0].isalpha():
            print "The first character of columns names must be alphabet!"
            exit()
        if val[0] == val.capitalize()[0]:
            class_vec.append(val)
            data_df[val] = data_df[val].astype('str')
        else:
            try:
                data_df[val] = data_df[val].astype('float')
            except Exception, e:
                print e
                print val, "may contain string, please check!"
                exit()
    
    s = 'Individual column: ' + id
    print s
    logfile_out.write(s + '\n')
    if id not in col_names:
        print id, 'is not in the data file, please check!'
        exit()
    if id not in class_vec:
        print 'The initial letter of', id, 'should be capital'
        exit()
    id_order = []
    id_arr = list(data_df[id])
    id_order.append(id_arr[0])
    for i in range(1, len(id_arr)):
        if id_arr[i] != id_arr[i - 1]:
            id_order.append(id_arr[i])
    id_in_data = np.array(data_df[id])
    if len(set(id_in_data)) - len(id_order) != 0:
        print 'The data is not sored by individual ID!'
        exit()
    
    s = 'Time points column: ' + tpoint
    print s
    logfile_out.write(s + '\n')
    if tpoint not in col_names:
        print tpoint, 'is not in the data file, please check!'
        exit()
    if tpoint in class_vec:
        print 'The initial letter of', tpoint, 'should be lowercase'
        exit()
    
    s = 'Trait column: ' + trait
    print s
    logfile_out.write(s + '\n')
    if trait not in col_names:
        print trait, 'is not in the data file, please check!'
        exit()
    if trait in class_vec:
        print 'The initial letter of', trait, 'should be lowercase'
        exit()
    
    s = 'Code factor variables of the data file: ' + ' '.join(list(class_vec))
    print s
    logfile_out.write(s + '\n')
    code_val = {}
    code_dct = dct_2D()
    for val in class_vec:
        code_val[val] = 0
        temp = []
        for i in range(data_df.shape[0]):
            if data_df[val][i] not in code_dct[val]:
                code_val[val] += 1
                code_dct[val][data_df[val][i]] = str(code_val[val])
            temp.append(code_dct[val][data_df[val][i]])
        data_df[val] = np.array(temp)
    for val in class_vec:
        data_df[val] = data_df[val].astype('int')
    
    s = '***Build the design matrix for fixed effect***'
    print s
    logfile_out.write(s + '\n')
    s = 'Time dependent fixed effect: ' + str(tfix)
    print s
    logfile_out.write(s + '\n')
    leg_fix = leg(data_df[tpoint], forder)
    snp_leg = np.concatenate(leg_fix, axis=1)
    if tfix is None:
        xmat_t = np.concatenate(leg_fix, axis=1)
        xmat_t = csr_matrix(xmat_t)
    else:
        if tfix not in class_vec:
            print tfix, 'is not the class variate'
            exit()
        row = np.array(range(data_df.shape[0]))
        col = np.array(data_df[tfix]) - 1
        val = np.array([1.0] * data_df.shape[0])
        tfix_mat = csr_matrix((val, (row, col)))
        xmat_t = []
        for i in range(len(leg_fix)):
            xmat_t.append(tfix_mat.multiply(leg_fix[i]))
        xmat_t = hstack(xmat_t)
        del row, col, val
        gc.collect()
    
    s = 'Time independent fix effect: ' + str(fix)
    print s
    logfile_out.write(s + '\n')
    if fix is None:
        xmat_nt = None
    else:
        try:
            xmat_nt = dmatrix(fix, data_df)
        except Exception, e:
            print e
            print 'Check the fix effect expression.'
            exit()
        xmat_nt = csr_matrix(xmat_nt[:, 1:])
    xmat = hstack([xmat_t, xmat_nt])
    xmat_null = xmat.toarray()
    y = np.array(data_df[trait]).reshape(data_df.shape[0], 1)
    
    s = '***Read the SNP data***'
    print s
    logfile_out.write(s + '\n')
    snp_on_disk = Bed(bed_file, count_A1=False)
    if len(set(id_order) - set(snp_on_disk.iid[:, -1])) != 0:
        print set(id_order) - set(snp_on_disk.iid[:, -1]), 'in the data file is not in the snp file!'
        exit()
    id_in_order_data = []
    for i in id_in_data:
        id_in_order_data.append(list(snp_on_disk.iid[:, -1]).index(i))
    if snp_lst is None:
        snp_lst = range(snp_on_disk.sid_count)
    else:
        try:
            snp_lst = np.array(snp_lst, dtype=int)
        except Exception, e:
            print e
            print 'The snp list value should be int'
            exit()
    snp_lst = list(snp_lst)
    if min(snp_lst) < 0 or max(snp_lst) >= snp_on_disk.sid_count:
        print 'The value in the snp list should be >=', 0, 'and <', snp_on_disk.sid_count
        exit()
    snp_data = snp_on_disk[:, snp_lst].read().val
    
    s = '***Start***'
    print s
    logfile_out.write(s + '\n')
    eff_vec = []
    chi_vec = []
    p_vec = []
    sigma_vec = []
    for i in range(snp_data.shape[1]):
        snp_i = snp_data[id_in_order_data, i]
        snp_fix = snp_leg * snp_i.reshape(len(snp_i), 1)
        xmat = np.concatenate((xmat_null, snp_fix), axis=1)
        eff, eff_var, sigma = longwas_lm(y, xmat)
        sigma_vec.append(sigma)
        # print sigma
        snp_eff = eff[-(forder + 1):, -1]
        eff_vec.append(snp_eff)
        snp_eff_var = eff_var[-(forder + 1):, -(forder + 1):]
        chi_val = np.sum(reduce(np.dot, [snp_eff.T, np.linalg.inv(snp_eff_var), snp_eff]))
        p_val = chi2.sf(chi_val, forder + 1)
        chi_vec.append(chi_val)
        p_vec.append(p_val)
    
    endtime = datetime.datetime.now()
    s = "Running time: " + str((endtime - starttime).seconds) + ' seconds'
    print s
    
    s = '***Output***'
    print s
    logfile_out.write(s + '\n')
    snp_info_file = bed_file + '.bim'
    snp_info = pd.read_csv(snp_info_file, sep='\s+', header=None)
    res_df = snp_info.iloc[snp_lst, [0, 1, 3, 4, 5]]
    res_df.columns = ['chro', 'snp_ID', 'pos', 'allele1', 'allele2']
    res_df.loc[:, 'order'] = snp_lst
    res_df = res_df.iloc[:, [5, 0, 1, 2, 3, 4]]
    res_df.loc[:, 'sigma'] = sigma_vec
    eff_vec = np.array(eff_vec)
    for i in range(eff_vec.shape[1]):
        col_ind = 'eff' + str(i)
        res_df.loc[:, col_ind] = eff_vec[:, i]
    res_df.loc[:, 'chi_val'] = chi_vec
    res_df.loc[:, 'p_val'] = p_vec
    
    out_file = prefix_outfile + '.res'
    try:
        res_df.to_csv(out_file, sep=' ', index=False)
    except Exception, e:
        print e
        print 'Fail to output the result!'
        exit()
    
    return res_df
