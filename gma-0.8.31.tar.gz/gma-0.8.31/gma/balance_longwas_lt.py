import numpy as np
from scipy.sparse import csr_matrix
from pysnptools.snpreader import Bed
import pandas as pd
import datetime
from scipy.stats import chi2
import os

from balance_predata import *
from common import *


def balance_longwas_lt(data_file, id, tpoint, trait, kin_file, bed_file, var_com, snp_lst=None, tfix=None, fix=None,
            forder=3, rorder=3, na_method='omit', prefix_outfile='gma_balance_longwas_lt'):
    # os.chdir(os.path.dirname(os.path.abspath(data_file)))  # working directory
    logfile = prefix_outfile + '.log'
    logfile_out = open(logfile, "w")
    s = '################################'
    print s
    logfile_out.write(s + '\n')
    s = '###Prepare the related matrix###'
    print s
    logfile_out.write(s + '\n')
    s = '################################'
    print s
    logfile_out.write(s + '\n')
    
    starttime = datetime.datetime.now()
    if var_com.shape[0] != rorder*(rorder+1) + 2*(rorder+1) + 1:
        print 'Variances do not match the data, please check'
        exit()
    y, xmat, leg_tp, leg_fix, id_in_data_lst, kin_eigen_val, kin_eigen_vec = balance_predata(data_file, id, tpoint,
                trait, kin_file, logfile_out, tfix=tfix, fix=fix, forder=forder, rorder=rorder, na_method=na_method)
    
    s = '***Read the snp data***'
    print s
    logfile_out.write(s + '\n')
    snp_on_disk = Bed(bed_file, count_A1=False)
    if len(set(id_in_data_lst) - set(snp_on_disk.iid[:, -1])) != 0:
        print set(id_in_data_lst) - set(snp_on_disk.iid[:, -1]), 'in the data file is not in the snp file!'
        exit()
    id_in_data_index = []
    for i in id_in_data_lst:
        id_in_data_index.append(list(snp_on_disk.iid[:, -1]).index(i))
        # snp list
        if snp_lst is None:
            snp_lst = range(snp_on_disk.sid_count)
        else:
            try:
                snp_lst = np.array(snp_lst, dtype=int)
            except Exception, e:
                print e
                print 'The snp list value should be int'
                exit()
        snp_lst = list(snp_lst)
        if min(snp_lst) < 0 or max(snp_lst) >= snp_on_disk.sid_count:
            print 'The value in the snp list should be >=', 0, 'and <', snp_on_disk.sid_count
            exit()
    snp_data = snp_on_disk[id_in_data_index, snp_lst].read().val
    
    freq = np.sum(snp_data, axis=0) / (2 * snp_on_disk.iid_count)
    freq.shape = (1, len(freq))
    snp_data = snp_data - 2 * freq
    snp_data = np.dot(kin_eigen_vec.T, snp_data)
    
    s = '***Prepare the variance structure***'
    print s
    logfile_out.write(s + '\n')
    add_cov = var_com.loc[var_com.loc[:, 'vari']==1, :]
    row = np.array(add_cov['varij']) - 1
    col = np.array(add_cov['varik']) - 1
    val = add_cov['var_val']
    add_cov = csr_matrix((val, (row, col))).toarray()
    add_cov = add_cov + np.tril(add_cov, k=-1).T
    per_cov = var_com.loc[var_com.loc[:, 'vari'] == 2, :]
    row = np.array(per_cov['varij']) - 1
    col = np.array(per_cov['varik']) - 1
    val = per_cov['var_val']
    per_cov = csr_matrix((val, (row, col))).toarray()
    per_cov = per_cov + np.tril(per_cov, k=-1).T
    res_var = np.array(var_com['var_val'])[-1]
    
    vinv = np.multiply(kin_eigen_val.reshape(len(kin_eigen_val), 1, 1), tri_matT(leg_tp, add_cov)) + \
        tri_matT(leg_tp, per_cov) + np.diag([np.sum(res_var)] * leg_tp.shape[0])
    vinv = np.linalg.inv(vinv)
    vx = np.matmul(vinv, xmat)
    xvx = np.matmul(xmat.transpose(0, 2, 1), vx)
    xvx = reduce(np.add, xvx)
    xvx = np.linalg.inv(xvx)
    xvy = np.matmul(xmat.transpose(0, 2, 1), np.matmul(vinv, y))
    xvy = reduce(np.add, xvy)
    y_xb = y - np.matmul(xmat, np.dot(xvx, xvy))
    py = np.matmul(vinv, y_xb)
    
    endtime = datetime.datetime.now()
    s = "Running time: " + str((endtime - starttime).seconds) + ' seconds'
    print s
    logfile_out.write(s + '\n')
    
    s = '########################################################################'
    print s
    logfile_out.write(s + '\n')
    s = '###Start the linear transformation longitudinal GWAS for balance data###'
    print s
    logfile_out.write(s + '\n')
    s = '########################################################################'
    print s
    logfile_out.write(s + '\n')
    
    starttime = datetime.datetime.now()
    chi_df = leg_tp.shape[1]
    eff_vec = []
    chi_vec = []
    p_vec = []
    temp_gt = np.dot(add_cov, leg_tp.T)
    for i in range(snp_data.shape[1]):
        snpi = snp_data[:, i].reshape(snp_on_disk.iid_count, 1, 1)
        snpi = np.multiply(snpi, temp_gt)
        snp_eff = np.matmul(snpi, py)
        snp_eff = reduce(np.add, snp_eff)
        snp_cov1 = reduce(np.matmul, [snpi, vinv, snpi.transpose(0, 2, 1)])
        snp_cov1 = reduce(np.add, snp_cov1)
        snp_cov2 = np.matmul(snpi, vx)
        snp_cov2 = reduce(np.add, snp_cov2)
        snp_cov2 = reduce(np.dot, [snp_cov2, xvx, snp_cov2.T])
        snp_cov = snp_cov1 - snp_cov2
        chi_val = np.sum(np.dot(np.dot(snp_eff.T, np.linalg.inv(snp_cov)), snp_eff))
        p_val = chi2.sf(chi_val, chi_df)
        eff_vec.append(snp_eff)
        chi_vec.append(chi_val)
        p_vec.append(p_val)
    endtime = datetime.datetime.now()
    s = "Running time: " + str((endtime - starttime).seconds) + ' seconds'
    print s
    logfile_out.write(s + '\n')
    s = 'Finish association analysis'
    print s
    logfile_out.write(s + '\n')
    
    s = '***Output***'
    print s
    logfile_out.write(s + '\n')
    snp_info_file = bed_file + '.bim'
    snp_info = pd.read_csv(snp_info_file, sep='\s+', header=None)
    res_df = snp_info.iloc[snp_lst, [0, 1, 3, 4, 5]]
    res_df.columns = ['chro', 'snp_ID', 'pos', 'allele1', 'allele2']
    res_df.loc[:, 'order'] = snp_lst
    res_df = res_df.iloc[:, [5, 0, 1, 2, 3, 4]]
    eff_vec = np.array(eff_vec)
    for i in range(eff_vec.shape[1]):
        col_ind = 'eff' + str(i)
        res_df.loc[:, col_ind] = eff_vec[:, i]
    res_df.loc[:, 'chi_val'] = chi_vec
    res_df.loc[:, 'p_val'] = p_vec
    
    out_file = prefix_outfile + '.res'
    try:
        res_df.to_csv(out_file, sep=' ', index=False)
    except Exception, e:
        print e
        print 'Fail to output the result!'
        exit()
    return res_df
