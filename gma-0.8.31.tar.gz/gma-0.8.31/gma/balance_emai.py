import math
import numpy as np
from scipy import linalg
import datetime
import pandas as pd

from common import *
from pre_mat import *
from iter_mat import *


def balance_emai(y, xmat, leg_tp, kin_eigen_val, logfile_out, init=None, maxiter=30, cc_par=1.0e-8, cc_gra=1.0e-6,
                 cc_ll=0.001, em_weight_step=0.02):
    cov_dim = leg_tp.shape[1]
    y_var = np.var(y) / (cov_dim*2 + 1)
    print cov_dim, np.var(y), y_var
    num_record = y.shape[0]*y.shape[1]*y.shape[2]
    ran_df = len(kin_eigen_val)
    var_com = []
    cov_var = np.diag([y_var]*cov_dim)
    var_com.extend(cov_var[np.tril_indices_from(cov_var)])
    var_com.extend(cov_var[np.tril_indices_from(cov_var)])
    var_com.append(y_var)
    if init is None:
        var_com = np.array(var_com)
    else:
        if len(var_com) != len(init):
            print 'The length of initial variances should be', len(var_com)
            exit()
        else:
            var_com = np.array(init)
    var_com_em = var_com.copy()
    s = "initial variances: " + ' '.join(np.array(var_com, dtype=str))
    print s
    logfile_out.write(s + '\n')
    
    # check the varinaces
    cov = pre_cov_mat_eigen(cov_dim, var_com)
    if cov is None:
        print 'The covariances are not positive defined!'
        exit()
    cov_add, cov_per, cov_res = cov[:]
    
    var_ind = np.tril_indices_from(cov_add)
    a = [0] * len(var_ind[0])
    a.extend([1]*len(var_ind[0]))
    a.append(2)
    b = list(var_ind[0])
    b.extend(b)
    b.append(0)
    c = list(var_ind[1])
    c.extend(c)
    c.append(0)
    var_ind = np.array([a, b, c]).T
    kin_dct = {
        0: kin_eigen_val.reshape(len(kin_eigen_val), 1, 1),
        1: 1.0,
        2: 1.0
    }
    # em weight vector
    if em_weight_step <= 0.0 or em_weight_step > 1.0:
        print 'The em weight step should be between 0 (not include) and 1 (include)'
        exit()
    iter_count = 0
    em2ai_iter_count = 0
    em_inter_count = 0
    cc_par_val = 1000.0
    cc_gra_val = 1000.0
    ll_val = 1000.0
    cc_ll_val = 1000.0
    ll_val_pre = 1.0e30
    while iter_count < maxiter:
        iter_count += 1
        em2ai_iter_count += 1
        s = '***Start the iteration: ' + str(iter_count) + '***'
        print s
        logfile_out.write(s + '\n')
        # fd ai matrix
        fd_mat, ai_mat = pre_fdai_mat_eigen_glm(y, xmat, leg_tp, kin_eigen_val, cov_add, cov_per, cov_res, var_com,
                                            var_ind, kin_dct)
        # updated
        delta = np.dot(linalg.inv(ai_mat), fd_mat)
        var_com_update = var_com + delta
        cov = pre_cov_mat_eigen(cov_dim, var_com_update)
        if cov is None:
            em_inter_count += 1
            s = 'This is EM iteration: ' + str(em_inter_count)
            print s
            logfile_out.write(s + '\n')
            cov = pre_cov_mat_eigen(cov_dim, var_com_em)  # update the inversion of variances with the nearest em
            cov_add, cov_per, cov_res = cov[:]
            if em2ai_iter_count != 1:  # update the related matrix with the nearest em
                fd_mat, ai_mat = pre_fdai_mat_eigen_glm(y, xmat, leg_tp, kin_eigen_val, cov_add, cov_per, cov_res,
                                                      var_com, var_ind, kin_dct)
            # em matrix
            em_mat = pre_em_mat_eigen(cov_dim, cov_add, cov_per, ran_df, var_com, num_record)
            em2ai_iter_count = 0
            
            # # Increase em weight to guarantee variances positive
            gamma = 0.0
            while gamma < 1.0:
                gamma = gamma + em_weight_step
                if gamma >= 1.0:
                    gamma = 1.0
                wemai_mat = (1 - gamma) * ai_mat + gamma * em_mat
                delta = np.dot(linalg.inv(wemai_mat), fd_mat)
                var_com_update = var_com + delta
                cov = pre_cov_mat_eigen(cov_dim, var_com_update)
                if cov is not None:
                    s = 'EM weight value: ' + str(gamma)
                    print s
                    logfile_out.write(s + '\n')
                    break
            var_com_em = var_com_update.copy()
        s = 'Updated variances: ' + ' '.join(np.array(var_com_update, dtype=str))
        print s
        logfile_out.write(s + '\n')
        if cov is None:
            print "Updated variances is not positive define!"
            exit()
        cov_add, cov_per, cov_res = cov[:]
        # Convergence criteria
        cc_par_val = np.sum(pow(delta, 2)) / np.sum(pow(var_com_update, 2))
        cc_par_val = np.sqrt(cc_par_val)
        cc_gra_val = np.sqrt(np.sum(pow(fd_mat, 2)))
        var_com = var_com_update.copy()
        
        s = "Change in parameters, Norm of gradient vector: " + str(cc_par_val) + ', ' + str(cc_gra_val)
        print s
        logfile_out.write(s + '\n')
        
        # log likelihood value
        vinv = np.multiply(kin_eigen_val.reshape(len(kin_eigen_val), 1, 1), tri_matT(leg_tp, cov_add)) + \
               tri_matT(leg_tp, cov_per) + np.diag([np.sum(cov_res)] * leg_tp.shape[0])
        log_det_v = np.array(map(np.linalg.slogdet, vinv))
        log_det_v = np.sum(log_det_v[:, -1])
        vinv = np.linalg.inv(vinv)
        xvx = reduce(np.matmul, [xmat.transpose(0, 2, 1), vinv, xmat])
        xvx = reduce(np.add, xvx)
        log_det_xvx = np.linalg.slogdet(xvx)[1]
        xvx = np.linalg.inv(xvx)
        xvy = np.matmul(xmat.transpose(0, 2, 1), np.matmul(vinv, y))
        xvy = reduce(np.add, xvy)
        y_xb = y - np.matmul(xmat, np.dot(xvx, xvy))
        ypy = np.sum(np.matmul(y.transpose(0, 2, 1), np.matmul(vinv, y_xb)))
        ll_val = log_det_v + log_det_xvx + ypy
        s = "-2logL:" + str(ll_val)
        print s
        logfile_out.write(s + '\n')
        cc_ll_val = abs(ll_val_pre - ll_val)
        ll_val_pre = ll_val
        
        if cc_par_val < cc_par and cc_gra_val < cc_gra and cc_ll_val < cc_ll:
            break
    
    if cc_par_val < cc_par and cc_gra_val < cc_gra and cc_ll_val < cc_ll:
        convergence = True
        s = "Variances Converged"
        print s
        logfile_out.write(s + '\n')
    else:
        convergence = False
        s = "Variances Not Converged"
        print s
        logfile_out.write(s + '\n')
    
    aic_val = 2.0 * len(var_com) + ll_val
    s = "AIC value:" + str(aic_val)
    print s
    logfile_out.write(s + '\n')
    bic_val = len(var_com) * math.log(num_record) + ll_val
    s = "BIC value:" + str(bic_val)
    print s
    logfile_out.write(s + '\n')
    
    var_pd = {'vari': np.array(var_ind[:, 0]) + 1,
              "varij": np.array(var_ind[:, 1]) + 1,
              "varik": np.array(var_ind[:, 2]) + 1,
              "var_val": var_com}
    var_pd = pd.DataFrame(var_pd, columns=['vari', "varij", "varik", "var_val"])
    res = {'variances': var_pd,
           'cc_par': cc_par_val,
           'cc_gra': cc_par_val,
           'convergence': convergence,
           'll': ll_val,
           'AIC': aic_val,
           'BIC': bic_val}
    return res
