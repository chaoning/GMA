from setuptools import setup, find_packages

setup(
    name='gma',
    version='0.8.31',
    description='Genomic Multivariate Analysis Tool',
    author='Ning Chao',
    author_email='ningchao91@gmail.com',
    packages=['gma'],
    include_package_data = True
)
