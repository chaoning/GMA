import datetime
# import os

from common import *
from unbalance_predata import *
from unbalance_emai import *



def unbalance_varcom(data_file, id, tpoint, trait, kin_inv_file, tfix=None, fix=None, forder=3, aorder=3, porder=3,
             na_method='omit', fixcon=False, rancon=True, init=None, maxiter=200, cc_par=1.0e-8, cc_gra=1.0e6,
                     cc_ll=1.0e6, em_weight_step=0.01, prefix_outfile='gma_unbalance_varcom'):
    # os.chdir(os.path.dirname(os.path.abspath(data_file)))
    logfile = prefix_outfile + '.log'
    logfile_out = open(logfile, "w")
    s = '########################################################################'
    print s
    logfile_out.write(s + '\n')
    s = '###Prepare the data for unbalanced longitudinal variances estimation.###'
    print s
    logfile_out.write(s + '\n')
    s = '########################################################################'
    print s
    logfile_out.write(s + '\n')
    
    start_time = datetime.datetime.now()
    y, xmat, zmat, kin_inv, leg_lst, code_dct, id_order = unbalance_predata(data_file, id, tpoint, trait, kin_inv_file,
            logfile_out, tfix=tfix, fix=fix, forder=forder, aorder=aorder, porder=porder, na_method=na_method)
    end_time = datetime.datetime.now()
    s = "Running time: " + str((end_time - start_time).seconds) + ' seconds'
    print s
    logfile_out.write(s + '\n')
    
    s = '###########################################################'
    print s
    logfile_out.write(s + '\n')
    s = '###Start the unbalanced longitudinal variances estimation###'
    print s
    logfile_out.write(s + '\n')
    s = '###########################################################'
    print s
    logfile_out.write(s + '\n')
    res = unbalance_emai(y, xmat, zmat, kin_inv, logfile_out, fixcon=fixcon, rancon=rancon, init=init,
                maxiter=maxiter, cc_par=cc_par, cc_gra=cc_gra, cc_ll=cc_ll, em_weight_step=em_weight_step)
    logfile_out.close()
    var_file = prefix_outfile + '.var'
    res['variances'].to_csv(var_file, sep=' ', index=False)
    return res
