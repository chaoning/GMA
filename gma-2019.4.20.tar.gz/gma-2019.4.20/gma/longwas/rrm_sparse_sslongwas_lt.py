import numpy as np
from pysnptools.snpreader import Bed
import pandas as pd
from scipy.sparse import csr_matrix, coo_matrix, triu, tril
from scipy.stats import chi2
import datetime
import gc
import os

from rrm_sparse_predata import *
from pre_mat import *

def rrm_sparse_sslongwas_lt(data_file, id, tpoint, trait, bed_file, kin_file, kin_inv_file, hmat_inv_file, var_com,
                            snp_lst=None, tfix=None, fix=None, forder=3, aorder=3, porder=3, na_method='omit',
                         prefix_outfile='gma_rrm_sparse_sslongwas_lt'):
    # os.chdir(os.path.dirname(os.path.abspath(data_file)))
    logfile = prefix_outfile + '.log'
    logfile_out = open(logfile, "w")
    s = '################################'
    print s
    logfile_out.write(s + '\n')
    s = '###Prepare the related matrix###'
    print s
    logfile_out.write(s + '\n')
    s = '################################'
    print s
    logfile_out.write(s + '\n')
    
    start_time = datetime.datetime.now()
    if var_com.shape[0] != aorder * (aorder + 1) / 2 + aorder + 1 + porder * (porder + 1) / 2 + porder + 1 + 1:
        print 'Variances do not match the data, please check'
        exit()
    y, xmat, zmat, kin_inv, leg_lst, code_dct, id_in_order = rrm_sparse_predata(data_file, id, tpoint, trait,
                                                                               hmat_inv_file, logfile_out, tfix=tfix,
                                                                               fix=fix, forder=forder, aorder=aorder,
                                                                               porder=porder, na_method=na_method)
    
    s = '***Prepare the CMi and effect***'
    print s
    logfile_out.write(s + '\n')
    eff_ind = [[0, xmat.shape[1]]]  # the index for all effects [start end]
    zmat_con_lst = []  # combined random matrix
    cov_dim = []  # the dim for covariance matrix
    for i in range(len(zmat)):
        temp = [eff_ind[i][-1]]
        zmat_con_lst.append(hstack(zmat[i]))
        cov_dim.append(len(zmat[i]))
        for j in range(len(zmat[i])):
            temp.append(temp[-1] + zmat[i][j].shape[1])
        eff_ind.append(temp)
    zmat_con = hstack(zmat_con_lst)  # design matrix for random effects
    wmat = hstack([xmat, zmat_con])  # merged design matrix
    cmat_pure = np.dot(wmat.T, wmat)  # C matrix
    rhs_pure = wmat.T.dot(y)  # right hand
    covi_mat = pre_covi_mat(cov_dim, np.array(var_com['var_val']))
    cmat_inv, rhs_mat = pre_sparse_mat(y, xmat, eff_ind, zmat_con, cov_dim, np.array(var_com['var_val']), covi_mat, cmat_pure,
                               kin_inv, rhs_pure)
    # output the CM
    cmat_inv = cmat_inv.tocoo()
    cmat_inv = triu(cmat_inv)
    cmat_inv = pd.DataFrame({'a': cmat_inv.row + 1, 'b': cmat_inv.col + 1, 'c': cmat_inv.data})
    cmat_inv = cmat_inv.sort_values(by=['a', 'b'])
    # cmat_inv.to_csv('matrix.dat', sep=' ', header=False, index=False)
    # stri_com = 'wombat -v --invspa matrix.dat'
    # os.system(stri_com)
    cmat_inv = pd.read_csv('matrix.dat.inv', sep='\s+', header=None)
    cmat_inv = csr_matrix((cmat_inv.iloc[:, 2], (cmat_inv.iloc[:, 0]-1, cmat_inv.iloc[:, 1]-1)))
    cmat_inv = tril(cmat_inv) + tril(cmat_inv, k=-1).T
    eff = cmat_inv.dot(rhs_mat)
    
    add_cov = var_com.loc[var_com.loc[:, 'vari'] == 1, :]
    row = np.array(add_cov['varij']) - 1
    col = np.array(add_cov['varik']) - 1
    val = add_cov['var_val']
    add_cov = csr_matrix((val, (row, col))).toarray()
    add_cov = add_cov + np.tril(add_cov, k=-1).T
    
    s = '***Read the kinship matrix***'
    print s
    logfile_out.write(s + '\n')
    kin_df = pd.read_csv(kin_file, sep='\s+', header=None)
    id_in_kin_len = len(set(kin_df.iloc[:, 0]))
    kin = np.zeros((id_in_kin_len, id_in_kin_len))
    kin[np.tril_indices_from(kin)] = kin_df.iloc[:, -1]
    kin = np.tril(kin) + np.tril(kin, k=-1).T
    del kin_df
    gc.collect()
    s = '***Read the inversion of kinship matrix***'
    print s
    logfile_out.write(s + '\n')
    kin_inv_df = pd.read_csv(kin_inv_file, sep='\s+', header=None)
    kin_inv = np.zeros((id_in_kin_len, id_in_kin_len))
    kin_inv[np.tril_indices_from(kin_inv)] = kin_inv_df.iloc[:, -1]
    kin_inv = np.tril(kin_inv) + np.tril(kin_inv, k=-1).T
    del kin_inv_df
    gc.collect()
    
    s = '***Rearrangement the inversion of CM and extract the additive part***'
    print s
    logfile_out.write(s + '\n')
    fam_file = bed_file + '.fam'
    id_fam_order = []
    fin = open(fam_file)
    line = fin.readline()
    while line:
        arr = line.split()
        id_fam_order.append(int(code_dct[arr[1]]))
        line = fin.readline()
    fin.close()
    
    eff_reorder_ind = []
    add_df = len(eff_ind[1]) - 1
    for i in range(len(id_fam_order)):
        for j in range(add_df):
            eff_reorder_ind.append(eff_ind[1][j] + id_fam_order[i] - 1)
    eff_reorder_ind = np.array(eff_reorder_ind)
    il = np.tril_indices(len(eff_reorder_ind))
    cmati_reorder_ind1 = eff_reorder_ind[il[0]]
    cmati_reorder_ind2 = eff_reorder_ind[il[1]]
    eff_reorder = eff[eff_reorder_ind, -1]
    np.savetxt('eff.txt', eff_reorder)
    cmati_reorder = np.zeros((len(eff_reorder_ind), len(eff_reorder_ind)))
    cmati_reorder[il] = np.array(cmat_inv[cmati_reorder_ind1, cmati_reorder_ind2])[0]
    del cmati_reorder_ind1, cmati_reorder_ind2, il, eff, cmat_inv
    gc.collect()
    cmati_reorder = cmati_reorder + np.tril(cmati_reorder, k=-1).T
    cmati_reorder = np.subtract(np.kron(kin, add_cov), cmati_reorder)
    
    s = '***Read the snp data***'
    print s
    logfile_out.write(s + '\n')
    snp_on_disk = Bed(bed_file, count_A1=False)
    if snp_lst is None:
        snp_lst = range(snp_on_disk.sid_count)
    else:
        try:
            snp_lst = np.array(snp_lst, dtype=int)
        except Exception, e:
            print e
            print 'The snp list value should be int'
            exit()
    snp_lst = list(snp_lst)
    if min(snp_lst) < 0 or max(snp_lst) >= snp_on_disk.sid_count:
        print 'The value in the snp list should be >=', 0, 'and <', snp_on_disk.sid_count
        exit()
    # if len(set(id_in_order) - set(snp_on_disk.iid[:, -1])) != 0:
    #    print set(id_in_order) - set(snp_on_disk.iid[:, -1]), 'in the data file is not in the snp file!'
    #    exit()
    # id_in_order_index = []
    # for i in id_in_order:
    #     id_in_order_index.append(list(snp_on_disk.iid[:, -1]).index(i))
    # snp_data = snp_on_disk[id_in_order_index, snp_lst].read().val
    snp_data = snp_on_disk[:, snp_lst].read().val
    freq = np.sum(snp_data, axis=0) / (2 * snp_on_disk.iid_count)
    freq.shape = (1, len(freq))
    snp_data = snp_data - 2 * freq
    
    chi_df = leg_lst[0].shape[1]
    eff_vec = []
    chi_vec = []
    p_vec = []
    end_time = datetime.datetime.now()
    s = "Running time: " + str((end_time - start_time).seconds) + ' seconds'
    print s
    logfile_out.write(s + '\n')
    
    s = '##########################################################################'
    print s
    logfile_out.write(s + '\n')
    s = '###Start the linear transformation longitudinal GWAS for unbalance data###'
    print s
    logfile_out.write(s + '\n')
    s = '##########################################################################'
    print s
    logfile_out.write(s + '\n')
    starttime = datetime.datetime.now()
    speye = np.eye(chi_df, dtype=float)
    for i in range(snp_data.shape[1]):
        snpi = np.dot(snp_data[:, i].reshape(1, snp_on_disk.iid_count), kin_inv)
        snpi = np.kron(snpi, speye)
        snp_eff = np.dot(snpi, eff_reorder)
        snp_cov = reduce(np.dot, [snpi, cmati_reorder, snpi.T])
        chi_val = np.sum(np.dot(np.dot(snp_eff.T, np.linalg.inv(snp_cov)), snp_eff))
        p_val = chi2.sf(chi_val, chi_df)
        eff_vec.append(snp_eff)
        chi_vec.append(chi_val)
        p_vec.append(p_val)
    endtime = datetime.datetime.now()
    s = "Running time: " + str((endtime - starttime).seconds) + ' seconds'
    print s
    logfile_out.write(s + '\n')
    s = 'Finish association analysis'
    print s
    logfile_out.write(s + '\n')
    
    s = '***Output***'
    print s
    logfile_out.write(s + '\n')
    snp_info_file = bed_file + '.bim'
    snp_info = pd.read_csv(snp_info_file, sep='\s+', header=None)
    res_df = snp_info.iloc[snp_lst, [0, 1, 3, 4, 5]]
    res_df.columns = ['chro', 'snp_ID', 'pos', 'allele1', 'allele2']
    res_df.loc[:, 'order'] = snp_lst
    res_df = res_df.iloc[:, [5, 0, 1, 2, 3, 4]]
    eff_vec = np.array(eff_vec)
    for i in range(eff_vec.shape[1]):
        col_ind = 'eff' + str(i)
        res_df.loc[:, col_ind] = eff_vec[:, i]
    
    res_df.loc[:, 'chi_val'] = chi_vec
    res_df.loc[:, 'p_val'] = p_vec
    
    out_file = prefix_outfile + '.res'
    try:
        res_df.to_csv(out_file, sep=' ', index=False)
    except Exception, e:
        print e
        print 'Fail to output the result!'
        exit()
    return res_df
