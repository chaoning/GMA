import numpy as np
from scipy import linalg
from pysnptools.snpreader import Bed
import pandas as pd
from uvlmm_varcom import uvlmm_varcom_fixed
import datetime
from scipy.stats import chi2



def uvlmm_fixed(y, xmat, bed_file, kin_eigen_vec, kin_eigen_val, varcom, out_file=None, maxiter=100, cc=1.0e-8):
    y = np.dot(kin_eigen_vec.T, y)
    xmat = np.dot(kin_eigen_vec.T, xmat)
    snp_on_disk = Bed(bed_file, count_A1=False)
    snp_mat = snp_on_disk.read().val
    freq = np.sum(snp_mat, axis=0) / (2 * snp_on_disk.iid_count)
    freq.shape = (1, snp_on_disk.sid_count)
    snp_mat = snp_mat - 2 * freq
    print 'Start GWAS'
    cc_vec = []
    eff_vec = []
    p_vec = []
    starttime = datetime.datetime.now()
    snp_mat = np.dot(kin_eigen_vec.T, snp_mat)
    for i in range(snp_mat.shape[1]):
        snpi = snp_mat[:, i]
        snpi = snpi[:, np.newaxis]
        xmati = np.concatenate((xmat, snpi), axis=1)
        cc_val, eff, p_val = uvlmm_varcom_fixed(y, xmati, kin_eigen_vec, kin_eigen_val, init=varcom, maxiter=maxiter,
                                                cc=cc)
        print cc_val, eff, p_val
        cc_vec.append(cc_val)
        eff_vec.append(eff)
        p_vec.append(p_val)
    endtime = datetime.datetime.now()
    print "Running time", (endtime - starttime).seconds
    print 'Finish'
    snp_info_file = bed_file + '.bim'
    snp_info = pd.read_csv(snp_info_file, sep='\s+', header=None)
    res_df = snp_info.iloc[:, [0, 1, 3, 4, 5]]
    res_df.columns = ['chro', 'snp_ID', 'pos', 'allele1', 'allele2']
    res_df.loc[:, 'cc_val'] = cc_vec
    res_df.loc[:, 'eff_val'] = eff_vec
    res_df.loc[:, 'p_val'] = p_vec
    if out_file is not None:
        try:
            res_df.to_csv(out_file, sep=' ', index=False)
        except Exception, e:
            print e
            print 'Fail to output the result!'
            exit()
    return res_df
