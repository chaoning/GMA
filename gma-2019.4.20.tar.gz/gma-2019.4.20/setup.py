from setuptools import setup, find_packages

setup(
    name='gma',
    version='2019.4.20',
    description='Genomic Multivariate Analysis Tool',
    author='Ning Chao',
    author_email='ningchao91@gmail.com',
    packages=find_packages(),
    url="https://github.com/chaoning/GMA",
    include_package_data = True,
)
