import datetime
import os

from common import *
from balance_emai import *
from balance_predata import *


def balance_varcom(data_file, id, tpoint, trait, kin_file, tfix=None, fix=None, forder=3, rorder=3, na_method='omit',
                   init=None, maxiter=200, cc_par=1.0e-8, cc_gra=1.0e6, cc_ll=1.0e6, em_weight_step=0.01,
                   prefix_outfile='gma_balance_varcom'):
    # os.chdir(os.path.dirname(os.path.abspath(data_file)))
    logfile = prefix_outfile + '.log'
    logfile_out = open(logfile, "w")
    s = '########################################################################'
    print s
    logfile_out.write(s + '\n')
    s = '###Prepare the data for unbalanced longitudinal variances estimation.###'
    print s
    logfile_out.write(s + '\n')
    s = '########################################################################'
    print s
    logfile_out.write(s + '\n')
    start_time = datetime.datetime.now()
    y, xmat_t, leg_tp, leg_fix, id_in_data_lst, kin_eigen_val, kin_eigen_vec = balance_predata(data_file, id, tpoint,
                trait, kin_file, logfile_out, tfix=tfix, fix=fix, forder=forder, rorder=rorder, na_method=na_method)
    end_time = datetime.datetime.now()
    s = "Running time: " + str((end_time - start_time).seconds) + ' seconds'
    print s
    logfile_out.write(s + '\n')
    
    s = '##########################################################'
    print s
    logfile_out.write(s + '\n')
    s = '###Start the balanced longitudinal variances estimation###'
    print s
    logfile_out.write(s + '\n')
    s = '##########################################################'
    print s
    logfile_out.write(s + '\n')
    start_total = datetime.datetime.now()
    res = balance_emai(y, xmat_t, leg_tp, kin_eigen_val, logfile_out, init=init, maxiter=maxiter, cc_par=cc_par,
                       cc_gra=cc_gra, cc_ll=cc_ll, em_weight_step=em_weight_step)
    end_total = datetime.datetime.now()
    s = "Total running time: " + str((end_total - start_total).seconds) + ' seconds'
    print s
    logfile_out.write(s + '\n')
    var_file = prefix_outfile + '.var'
    res['variances'].to_csv(var_file, sep=' ', index=False)
    return res
