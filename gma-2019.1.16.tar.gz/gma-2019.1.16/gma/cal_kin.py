import numpy as np
from pysnptools.snpreader import Bed
import pandas as pd
import datetime
import math
from copy import deepcopy
from common import dct_2D


def cal_kin(bed_file, inv=True, small_val=0.001):
    print "Read the SNP data."
    start_time = datetime.datetime.now()
    snp_on_disk = Bed(bed_file, count_A1=False)
    snp_mat = snp_on_disk.read().val
    end_time = datetime.datetime.now()
    print "Running time:", (end_time - start_time).seconds, 'seconds'
    
    print 'Calculate the SNP frequency.'
    start_time = datetime.datetime.now()
    freq = np.sum(snp_mat, axis=0) / (2 * snp_on_disk.iid_count)
    freq.shape = (1, snp_on_disk.sid_count)
    scale = 2 * freq * (1 - freq)
    scale = np.sum(scale)
    if math.isnan(scale):
        print 'Missing genotypes are not allowed!!!'
        exit()
    
    print 'Centralize the SNP data'
    snp_mat = snp_mat - 2*freq
    end_time = datetime.datetime.now()
    print "Running time:", (end_time - start_time).seconds, 'seconds'
    
    print 'Calculate the kinship'
    start_time = datetime.datetime.now()
    kin = np.dot(snp_mat, snp_mat.T)/scale
    kin_diag = np.diag(kin)
    kin_diag = kin_diag + kin_diag * small_val
    np.fill_diagonal(kin, kin_diag)
    end_time = datetime.datetime.now()
    print "Running time:", (end_time - start_time).seconds, 'seconds'
    
    print 'Output the kinship'
    start_time = datetime.datetime.now()
    ind = np.tril_indices_from(kin)
    val = kin[ind]
    id1 = snp_on_disk.iid[:, 1][ind[0]]
    id2 = snp_on_disk.iid[:, 1][ind[1]]
    data_df = {'id1': id1, 'id2': id2, 'val': val}
    data_df = pd.DataFrame(data_df, columns=['id1', 'id2', 'val'])
    kin_file = bed_file + '.grm'
    data_df.to_csv(kin_file, sep=' ', header=False, index=False)
    end_time = datetime.datetime.now()
    print "Running time:", (end_time - start_time).seconds, 'seconds'
    
    kin_inv = None
    if inv:
        print 'Calculate the inversion of kinship'
        start_time = datetime.datetime.now()
        kin_inv = np.linalg.inv(kin)
        end_time = datetime.datetime.now()
        print "Running time:", (end_time - start_time).seconds, 'seconds'
        
        print 'Output the inversion'
        start_time = datetime.datetime.now()
        val = kin_inv[ind]
        data_df = {'id1': id1, 'id2': id2, 'val': val}
        data_df = pd.DataFrame(data_df, columns=['id1', 'id2', 'val'])
        kin_inv_file = bed_file + '.giv'
        data_df.to_csv(kin_inv_file, sep=' ', header=False, index=False)
        end_time = datetime.datetime.now()
        print "Running time:", (end_time - start_time).seconds, 'seconds'
    
    return [kin, kin_inv]


def ped_trace(ped_file, full_ped_file, gen=10000):
    ped_id = {}
    ped_dct = {}
    fin = open(ped_file)
    line = fin.readline()
    while line:
        arr = line.split()
        if arr[0] == '0':
            print "0 is not allowed for id"
            exit()
        ped_id[arr[0]] = 1
        ped_dct[arr[0]] = arr[0] + '\t0\t0\n'
        line = fin.readline()
    fin.close()
    if '0' in ped_id:
        ped_id.pop('0')
    if '0' in ped_dct:
        ped_dct.pop('0')
    for i in range(gen):
        ped_len1 = len(ped_id.keys())
        fin = open(full_ped_file)
        line = fin.readline()
        while line:
            arr = line.split()
            if arr[0] in ped_id:
                ped_dct[arr[0]] = '\t'.join(arr[0:3])
                if arr[1] != '0':
                    ped_id[arr[1]] = 1
                if arr[2] != '0':
                    ped_id[arr[2]] = 1
            line = fin.readline()
        fin.close()
        ped_len2 = len(ped_id.keys())
        if ped_len1 == ped_len2:
            break
    fout = open(ped_file + '.trace', 'w')
    for ikey in ped_dct.keys():
        fout.write(ped_dct[ikey] + '\n')
    fout.close()
    return 0

def ped_correct(ped_file):
    # store the ped
    ped_dct = {}
    fin = open(ped_file)
    line = fin.readline()
    while line:
        arr = line.split()
        ped_dct[arr[0]] = [arr[1], arr[2]]
        line = fin.readline()
    fin.close()
    # trace the ancestor
    anc = dct_2D()
    fin = open(ped_file)
    line = fin.readline()
    while line:
        arr = line.split()
        if arr[1] != '0':
            anc[arr[0]][arr[1]] = 1
        if arr[2] != '0':
            anc[arr[0]][arr[2]] = 1
        d = 1000
        while d > 0:
            id_key = anc[arr[0]].keys()
            id_key_len1 = len(id_key)
            for i in id_key:
                if i in ped_dct:
                    anc[arr[0]][ped_dct[i][0]] = 0
                    anc[arr[0]][ped_dct[i][1]] = 0
            if '0' in anc[arr[0]].keys():
                anc[arr[0]].pop('0')
            id_key = anc[arr[0]].keys()
            id_key_len2 = len(id_key)
            d = id_key_len2 - id_key_len1
        line = fin.readline()
    fin.close()
    # correct the error
    fout = open(ped_file + '.error', 'w')
    for i in anc.keys():
        if i in anc[i].keys():
            stri = i + '\t' + ped_dct[i][0] + '\t' + ped_dct[i][1] + '\n'
            fout.write(stri)
            if ped_dct[i][0] != '0' and i in anc[ped_dct[i][0]].keys():
                ped_dct[i][0] = '0'
            if ped_dct[i][1] != '0' and i in anc[ped_dct[i][1]].keys():
                ped_dct[i][1] = '0'
    fout.close()
    # output
    fout = open(ped_file + '.correct', 'w')
    for i in ped_dct.keys():
        stri = i + '\t' + ped_dct[i][0] + '\t' + ped_dct[i][1] + '\n'
        fout.write(stri)
    fout.close()
    return 0


def ped_sort(ped_file):
    # store the ped
    ped_dct = {}
    fin = open(ped_file)
    line = fin.readline()
    while line:
        arr = line.split()
        ped_dct[arr[0]] = ['0', '0']
        ped_dct[arr[1]] = ['0', '0']
        ped_dct[arr[2]] = ['0', '0']
        line = fin.readline()
    fin.close()
    fin = open(ped_file)
    line = fin.readline()
    while line:
        arr = line.split()
        ped_dct[arr[0]] = [arr[1], arr[2]]
        line = fin.readline()
    fin.close()
    if '0' in ped_dct:
        ped_dct.pop('0')
    # output the sorted ped
    output = {}
    output['0'] = 1
    ped_len = len(ped_dct.keys())
    fout = open(ped_file + '.sort', 'w')
    while ped_len > 0:
        for ikey in ped_dct.keys():
            if ped_dct[ikey][0] in output and ped_dct[ikey][1] in output:
                stri = '\t'.join([ikey, ped_dct[ikey][0], ped_dct[ikey][1]])
                fout.write(stri + '\n')
                output[ikey] = 1
                ped_dct.pop(ikey)
        ped_len = len(ped_dct.keys())
    fout.close()
    return 0

def cal_amat(ped_file):
    ped_mat = np.loadtxt(ped_file, dtype=str)
    id = ped_mat[:, 0]
    id_num = ped_mat.shape[0]
    amat = dct_2D()
    for i in range(id_num):
        arr1 = ped_mat[i, :]
        if arr1[1] != '0' and arr1[2] != '0' and arr1[2] in amat[arr1[1]]:
            amat[arr1[0]][arr1[0]] = 1.0 + 0.5*amat[arr1[1]][arr1[2]]
        else:
            amat[arr1[0]][arr1[0]] = 1.0
        for j in range(i):
            arr2 = ped_mat[j, :]
            if arr1[1] != '0' and arr1[2] != '0':
                if arr1[1] in amat[arr2[0]] and arr1[2] in amat[arr2[0]]:
                    amat[arr2[0]][arr1[0]] = 0.5 * (amat[arr2[0]][arr1[1]] + amat[arr2[0]][arr1[2]])
                    amat[arr1[0]][arr2[0]] = amat[arr2[0]][arr1[0]]
                elif arr1[1] in amat[arr2[0]]:
                    amat[arr2[0]][arr1[0]] = 0.5 * amat[arr2[0]][arr1[1]]
                    amat[arr1[0]][arr2[0]] = amat[arr2[0]][arr1[0]]
                elif arr1[2] in amat[arr2[0]]:
                    amat[arr2[0]][arr1[0]] = 0.5 * amat[arr2[0]][arr1[2]]
                    amat[arr1[0]][arr2[0]] = amat[arr2[0]][arr1[0]]
            elif arr1[2] != '0':
                if arr1[2] in amat[arr2[0]]:
                    amat[arr2[0]][arr1[0]] = 0.5 * amat[arr2[0]][arr1[2]]
                    amat[arr1[0]][arr2[0]] = amat[arr2[0]][arr1[0]]
            elif arr1[1] != '0':
                if arr1[1] in amat[arr2[0]]:
                    amat[arr2[0]][arr1[0]] = 0.5 * amat[arr2[0]][arr1[1]]
                    amat[arr1[0]][arr2[0]] = amat[arr2[0]][arr1[0]]
    fout = open(ped_file + '.amat', 'w')
    for i in range(len(id)):
        if id[i] in amat:
            for j in range(i+1):
                if id[j] in amat[id[i]]:
                    stri = '\t'.join([id[i], id[j], str(amat[id[i]][id[j]])])
                    fout.write(stri + '\n')



def cal_ainv(ped_file):
    ped_mat = np.loadtxt(ped_file, dtype=str)
    id_num = ped_mat.shape[0]
    id = ped_mat[:, 0]
    v = dict(zip(id, [0.0]*id_num))
    a = deepcopy(v)
    id_code = dict(zip(id, range(1, id_num+1)))
    ainv = dct_2D()
    for m in range(id_num):
        arr1 = ped_mat[m, :]
        if arr1[1] == '0' and arr1[2] == '0':
            v[arr1[0]] = 1.0
        elif arr1[1] == '0':
            v[arr1[0]] = np.sqrt(1.0 - 0.25*a[arr1[2]])
        elif arr1[2] == '0':
            v[arr1[0]] = np.sqrt(1.0 - 0.25 * a[arr1[1]])
        else:
            v[arr1[0]] = np.sqrt(1.0 - 0.25*(a[arr1[1]]+a[arr1[2]]))
        a[arr1[0]] = a[arr1[0]] + v[arr1[0]]*v[arr1[0]]
        for n in range(m+1, id_num):
            arr2 = ped_mat[n, :]
            if arr2[1] != '0' and id_code[arr2[1]] >= id_code[arr1[0]] and arr2[2] != '0' and id_code[arr2[2]] >= \
                    id_code[arr1[0]]:
                v[arr2[0]] = 0.5*(v[arr2[1]] + v[arr2[2]])
            elif arr2[1] != '0' and id_code[arr2[1]] >= id_code[arr1[0]]:
                v[arr2[0]] = 0.5 * v[arr2[1]]
            elif arr2[2] != '0' and id_code[arr2[2]] >= id_code[arr1[0]]:
                v[arr2[0]] = 0.5 * v[arr2[2]]
            else:
                v[arr2[0]] = 0.0
            a[arr2[0]] = a[arr2[0]] + v[arr2[0]] * v[arr2[0]]
        d = 1.0/(v[arr1[0]]*v[arr1[0]])
        if arr1[1] != '0' and arr1[2] != '0': # sire and dam
            if arr1[0] in ainv[arr1[0]]:
                ainv[arr1[0]][arr1[0]] += d
            else:
                ainv[arr1[0]][arr1[0]] = d
            if arr1[1] in ainv[arr1[0]]:
                ainv[arr1[1]][arr1[0]] += -0.5*d
                ainv[arr1[0]][arr1[1]] += -0.5*d
            else:
                ainv[arr1[1]][arr1[0]] = -0.5*d
                ainv[arr1[0]][arr1[1]] = -0.5*d
            if arr1[2] in ainv[arr1[0]]:
                ainv[arr1[2]][arr1[0]] += -0.5*d
                ainv[arr1[0]][arr1[2]] += -0.5*d
            else:
                ainv[arr1[2]][arr1[0]] = -0.5*d
                ainv[arr1[0]][arr1[2]] = -0.5*d
            if arr1[1] in ainv[arr1[1]]:
                ainv[arr1[1]][arr1[1]] += 0.25 * d
            else:
                ainv[arr1[1]][arr1[1]] = 0.25 * d
            if arr1[2] in ainv[arr1[2]]:
                ainv[arr1[2]][arr1[2]] += 0.25 * d
            else:
                ainv[arr1[2]][arr1[2]] = 0.25 * d
            if arr1[2] in ainv[arr1[1]]:
                ainv[arr1[1]][arr1[2]] += 0.25 * d
                ainv[arr1[2]][arr1[1]] += 0.25 * d
            else:
                ainv[arr1[1]][arr1[2]] = 0.25 * d
                ainv[arr1[2]][arr1[1]] = 0.25 * d
        elif arr1[1] != '0':  # sire
            if arr1[0] in ainv[arr1[0]]:
                ainv[arr1[0]][arr1[0]] += d
            else:
                ainv[arr1[0]][arr1[0]] = d
            if arr1[1] in ainv[arr1[0]]:
                ainv[arr1[1]][arr1[0]] += -0.5*d
                ainv[arr1[0]][arr1[1]] += -0.5*d
            else:
                ainv[arr1[1]][arr1[0]] = -0.5*d
                ainv[arr1[0]][arr1[1]] = -0.5*d
            if arr1[1] in ainv[arr1[1]]:
                ainv[arr1[1]][arr1[1]] += 0.25 * d
            else:
                ainv[arr1[1]][arr1[1]] = 0.25 * d
        elif arr1[2] != '0':  # dam
            if arr1[0] in ainv[arr1[0]]:
                ainv[arr1[0]][arr1[0]] += d
            else:
                ainv[arr1[0]][arr1[0]] = d
            if arr1[2] in ainv[arr1[0]]:
                ainv[arr1[2]][arr1[0]] += -0.5*d
                ainv[arr1[0]][arr1[2]] += -0.5*d
            else:
                ainv[arr1[2]][arr1[0]] = -0.5*d
                ainv[arr1[0]][arr1[2]] = -0.5*d
            if arr1[2] in ainv[arr1[2]]:
                ainv[arr1[2]][arr1[2]] += 0.25 * d
            else:
                ainv[arr1[2]][arr1[2]] = 0.25 * d
        else:
            if arr1[0] in ainv[arr1[0]]:
                ainv[arr1[0]][arr1[0]] += d
            else:
                ainv[arr1[0]][arr1[0]] = d
    fout = open(ped_file + '.ainv', 'w')
    for i in range(len(id)):
        if id[i] in ainv:
            for j in range(i+1):
                if id[j] in ainv[id[i]]:
                    stri = '\t'.join([id[i], id[j], str(ainv[id[i]][id[j]])])
                    fout.write(stri + '\n')
    fout.close()
