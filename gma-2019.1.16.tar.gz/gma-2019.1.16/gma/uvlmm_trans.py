import numpy as np
from scipy import linalg
from pysnptools.snpreader import Bed
import pandas as pd
import datetime
from scipy.stats import chi2



def uvlmm_trans(y, xmat, bed_file, kin_eigen_vec, kin_eigen_val, varcom, out_file=None):
    y = np.dot(kin_eigen_vec.T, y)
    xmat = np.dot(kin_eigen_vec.T, xmat)
    snp_on_disk = Bed(bed_file, count_A1=False)
    snp_mat = snp_on_disk.read().val
    freq = np.sum(snp_mat, axis=0) / (2 * snp_on_disk.iid_count)
    freq.shape = (1, snp_on_disk.sid_count)
    snp_mat = snp_mat - 2 * freq
    
    print 'Start GWAS'
    starttime = datetime.datetime.now()
    vmat = 1.0 / (kin_eigen_val * varcom[0] + varcom[1])
    vx = np.multiply(vmat, xmat)
    xvx = np.dot(xmat.T, vx)
    xvx = np.linalg.inv(xvx)
    
    # py
    xvy = np.dot(vx.T, y)
    y_xb = y - np.dot(xmat, np.dot(xvx, xvy))
    py = np.multiply(vmat, y_xb)
    
    snp_mat = np.dot(kin_eigen_vec.T, snp_mat)
    chi_vec = []
    p_vec = []
    eff_vec = np.dot(snp_mat.T, py)*varcom[0]
    eff_vec = eff_vec[:, -1]
    for i in range(snp_on_disk.sid_count):
        snpi = snp_mat[:, i:(i+1)]
        snp_var1 = np.sum(reduce(np.multiply, [snpi, vmat, snpi]))
        snp_var2 = np.dot(snpi.T, vx)
        snp_var2 = reduce(np.dot, [snp_var2, xvx, snp_var2.T])
        snp_var = (snp_var1 + np.sum(snp_var2)) * varcom[0] * varcom[0]
        chi_val = eff_vec[i]*eff_vec[i]/snp_var
        p_val = chi2.sf(chi_val, 1)
        chi_vec.append(chi_val)
        p_vec.append(p_val)
    
    endtime = datetime.datetime.now()
    print "Running time", (endtime - starttime).seconds
    print 'Finish'
    
    snp_info_file = bed_file + '.bim'
    snp_info = pd.read_csv(snp_info_file, sep='\s+', header=None)
    res_df = snp_info.iloc[:, [0, 1, 3, 4, 5]]
    res_df.columns = ['chro', 'snp_ID', 'pos', 'allele1', 'allele2']
    res_df.loc[:, 'eff_val'] = eff_vec
    res_df.loc[:, 'chi_val'] = chi_vec
    res_df.loc[:, 'p_val'] = p_vec
    
    if out_file is not None:
        try:
            res_df.to_csv(out_file, sep=' ', index=False)
        except Exception, e:
            print e
            print 'Fail to output the result!'
            exit()
    
    return res_df
