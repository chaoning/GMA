import numpy as np
from pysnptools.snpreader import Bed
import pandas as pd
from scipy import linalg
from scipy import sparse
from scipy.sparse import csr_matrix
from scipy.stats import chi2
import datetime
import gc

from unbalance_predata import *


def unbalance_longwas_fixed(data_file, id, tpoint, trait, bed_file, kin_file, kin_inv_file, var_com, snp_lst=None,
            tfix=None, fix=None, forder=3, aorder=3, porder=3, na_method='omit',
                             prefix_outfile='gma_unbalance_longwas_fixed'):
    # os.chdir(os.path.dirname(os.path.abspath(data_file)))
    logfile = prefix_outfile + '.log'
    logfile_out = open(logfile, "w")
    s = '################################'
    print s
    logfile_out.write(s + '\n')
    s = '###Prepare the related matrix###'
    print s
    logfile_out.write(s + '\n')
    s = '################################'
    print s
    logfile_out.write(s + '\n')
    
    start_time = datetime.datetime.now()
    if var_com.shape[0] != aorder*(aorder+1)/2 + aorder + 1 + porder*(porder+1)/2 + porder + 1 + 1:
        print 'Variances do not match the data, please check'
        exit()
    s = '***prepare the data***'
    print s
    logfile_out.write(s + '\n')
    y, xmat, zmat, kin_inv, leg_lst, code_dct, id_in_order = unbalance_predata(data_file, id, tpoint, trait,
            kin_inv_file, logfile_out, tfix=tfix, fix=fix, forder=forder, aorder=aorder,
                                                    porder=porder, na_method=na_method)
    
    s = '***Prepare the merged Z matrix***'
    print s
    logfile_out.write(s + '\n')
    eff_ind = [[0, xmat.shape[1]]]  # the index for all effects [start end]
    zmat_con_lst = []  # combined random matrix
    for i in range(len(zmat)):
        temp = [eff_ind[i][-1]]
        zmat_con_lst.append(hstack(zmat[i]))
        for j in range(len(zmat[i])):
            temp.append(temp[-1] + zmat[i][j].shape[1])
        eff_ind.append(temp)
    
    s = '***Read the kinship matrix***'
    print s
    logfile_out.write(s + '\n')
    s = 'Kinship file: ' + kin_file
    print s
    logfile_out.write(s + '\n')
    fin = open(kin_file)
    line = fin.readline()
    row = []
    col = []
    kin = []
    id_in_kin = {}
    while line:
        arr = line.split()
        id_in_kin[arr[0]] = 1
        id_in_kin[arr[1]] = 1
        if arr[0] not in code_dct:
            print arr[0], 'is not in the kinship inversion file!'
            exit()
        if arr[1] not in code_dct:
            print arr[1], 'is not in the kinship inversion file!'
            exit()
        row.append(int(code_dct[arr[0]]))
        col.append(int(code_dct[arr[1]]))
        kin.append(float(arr[2]))
        line = fin.readline()
    fin.close()
    id_not_in_kin = list(set(code_dct.keys()) - set(id_in_kin.keys()))
    if len(id_not_in_kin) != 0:
        print 'The ID:', id_not_in_kin, 'in the data file is not in the kinship file!'
        exit()
    kin = csr_matrix((np.array(kin), (np.array(row) - 1, np.array(col) - 1))).toarray()
    kin = np.add(kin, kin.T)
    kin[np.diag_indices_from(kin)] = 0.5 * np.diag(kin)
    del row, col
    gc.collect()
    end_time = datetime.datetime.now()
    s = "Running time: " + str((end_time - start_time).seconds) + ' seconds'
    print s
    logfile_out.write(s + '\n')
    
    s = '***Calculate the phenotypic (co)variance***'
    print s
    logfile_out.write(s + '\n')
    starttime = datetime.datetime.now()
    add_cov = var_com.loc[var_com.loc[:, 'vari']==1, :]
    row = np.array(add_cov['varij']) - 1
    col = np.array(add_cov['varik']) - 1
    val = add_cov['var_val']
    add_cov = csr_matrix((val, (row, col))).toarray()
    add_cov = add_cov + np.tril(add_cov, k=-1).T
    per_cov = var_com.loc[var_com.loc[:, 'vari']==2, :]
    row = np.array(per_cov['varij']) - 1
    col = np.array(per_cov['varik']) - 1
    val = per_cov['var_val']
    per_cov = csr_matrix((val, (row, col))).toarray()
    per_cov = per_cov + np.tril(per_cov, k=-1).T
    res_var = np.array(var_com['var_val'])[-1]
    vmat = zmat_con_lst[0].dot((zmat_con_lst[0].dot(np.kron(add_cov, kin))).T)
    one_id = sparse.eye(zmat_con_lst[1].shape[1]/per_cov.shape[0])
    vmat = vmat + zmat_con_lst[1].dot((zmat_con_lst[1].dot(sparse.kron(per_cov, one_id))).T)
    vmat_diag = np.diag(vmat) + res_var
    np.fill_diagonal(vmat, vmat_diag)
    endtime = datetime.datetime.now()
    s = "Running time: " + str((endtime - starttime).seconds) + ' seconds'
    print s
    logfile_out.write(s + '\n')
    
    s = '***Start eigen decomposition of phenotypic variance matrix***'
    print s
    logfile_out.write(s + '\n')
    starttime = datetime.datetime.now()
    vmat_eigen_val, vmat_eigen_vec = linalg.eigh(vmat)
    endtime = datetime.datetime.now()
    s = "Running time: " + str((endtime - starttime).seconds) + ' seconds'
    print s
    logfile_out.write(s + '\n')
    y = np.dot(vmat_eigen_vec.T, y)
    xmat = np.dot(vmat_eigen_vec.T, xmat.toarray())
    
    s = '***Read the snp data***'
    print s
    logfile_out.write(s + '\n')
    snp_on_disk = Bed(bed_file, count_A1=False)
    if len(set(id_in_order) - set(snp_on_disk.iid[:, -1])) != 0:
        print set(id_in_order) - set(snp_on_disk.iid[:, -1]), 'in the data file is not in the snp file!'
        exit()
    id_in_order_index = []
    for i in id_in_order:
        id_in_order_index.append(list(snp_on_disk.iid[:, -1]).index(i))
    if snp_lst is None:
        snp_lst = range(snp_on_disk.sid_count)
    else:
        try:
            snp_lst = np.array(snp_lst, dtype=int)
        except Exception, e:
            print e
            print 'The snp list value should be int'
            exit()
    snp_lst = list(snp_lst)
    if min(snp_lst) < 0 or max(snp_lst) >= snp_on_disk.sid_count:
        print 'The value in the snp list should be >=', 0, 'and <', snp_on_disk.sid_count
        exit()
    snp_data = snp_on_disk[id_in_order_index, snp_lst].read().val
    
    s = '#####################################################################'
    print s
    logfile_out.write(s + '\n')
    s = '###Start the fixed regression longitudinal GWAS for unbalance data###'
    print s
    logfile_out.write(s + '\n')
    s = '#####################################################################'
    print s
    logfile_out.write(s + '\n')
    chi_df = leg_lst[0].shape[1]
    eff_vec = []
    chi_vec = []
    p_vec = []
    starttime = datetime.datetime.now()
    for i in range(snp_data.shape[1]):
        snp_fix = map(lambda x, y: np.multiply(x, y), leg_lst, list(snp_data[:, i]))
        snp_fix = np.concatenate(snp_fix, axis=0)
        snp_fix = np.dot(vmat_eigen_vec.T, snp_fix)
        snp_fix = np.concatenate((xmat, snp_fix), axis=1)
        xv = snp_fix.T * (1/vmat_eigen_val)
        xvx = np.dot(xv, snp_fix)
        xvx = np.linalg.inv(xvx)
        xvy = np.dot(xv, y)
        b = np.dot(xvx, xvy)
        chi_val = np.sum(np.dot(np.dot(b[-chi_df:, -1].T, np.linalg.inv(xvx[-chi_df:, -chi_df:])), b[-chi_df:, -1]))
        p_val = chi2.sf(chi_val, chi_df)
        eff_vec.append(b[-chi_df:, -1])
        chi_vec.append(chi_val)
        p_vec.append(p_val)
    endtime = datetime.datetime.now()
    s = "Running time: " + str((endtime - starttime).seconds) + ' seconds'
    print s
    logfile_out.write(s + '\n')
    s = 'Finish association analysis'
    print s
    logfile_out.write(s + '\n')
    
    s = '***Output***'
    print s
    logfile_out.write(s + '\n')
    snp_info_file = bed_file + '.bim'
    snp_info = pd.read_csv(snp_info_file, sep='\s+', header=None)
    res_df = snp_info.iloc[snp_lst, [0, 1, 3, 4, 5]]
    res_df.columns = ['chro', 'snp_ID', 'pos', 'allele1', 'allele2']
    res_df.loc[:, 'order'] = snp_lst
    res_df = res_df.iloc[:, [5, 0, 1, 2, 3, 4]]
    eff_vec = np.array(eff_vec)
    for i in range(eff_vec.shape[1]):
        col_ind = 'eff' + str(i)
        res_df.loc[:, col_ind] = eff_vec[:, i]
    res_df.loc[:, 'chi_val'] = chi_vec
    res_df.loc[:, 'p_val'] = p_vec
    
    out_file = prefix_outfile + '.res'
    try:
        res_df.to_csv(out_file, sep=' ', index=False)
    except Exception, e:
        print e
        print 'Fail to output the result!'
        exit()
    
    return res_df
