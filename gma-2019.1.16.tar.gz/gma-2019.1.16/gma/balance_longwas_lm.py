import numpy as np
from pysnptools.snpreader import Bed
import pandas as pd
import datetime
from scipy.stats import chi2

from common import *


def balance_longwas_lm(data_file, id, tpoint, trait, bed_file, snp_lst=None, forder=3,
                         na_method='omit', prefix_outfile='gma_unbalance_longwas_lm'):
    logfile = prefix_outfile + '.log'
    logfile_out = open(logfile, "w")
    s = '####################################################'
    print s
    logfile_out.write(s + '\n')
    s = '###Start the longitudinal linear model based GWAS###'
    print s
    logfile_out.write(s + '\n')
    s = '####################################################'
    print s
    logfile_out.write(s + '\n')
    starttime = datetime.datetime.now()
    s = '***Read the data file***'
    print s
    logfile_out.write(s + '\n')
    s = 'Data file: ' + data_file
    print s
    logfile_out.write(s + '\n')
    try:
        data_df = pd.read_csv(data_file, sep='\s+', header=0)
    except Exception, e:
        print e
        print "Fail to open the data file."
        exit()
    
    s = 'NA method: ' + na_method
    print s
    logfile_out.write(s + '\n')
    if na_method == 'omit':
        data_df = data_df.dropna()
    elif na_method == 'include':
        data_df = data_df.fillna(method='ffill')
        data_df = data_df.fillna(method='bfill')
    else:
        print 'na_method does not exist', na_method
        exit()
    
    col_names = data_df.columns
    s = 'The column names of data file: ' + ' '.join(list(col_names))
    print s
    logfile_out.write(s + '\n')
    s = 'Note: Variates beginning with a capital letter is converted into factors.'
    print s
    logfile_out.write(s + '\n')
    class_vec = []
    for val in col_names:
        if not val[0].isalpha():
            print "The first character of columns names must be alphabet!"
            exit()
        if val[0] == val.capitalize()[0]:
            class_vec.append(val)
            data_df[val] = data_df[val].astype('str')
        else:
            try:
                data_df[val] = data_df[val].astype('float')
            except Exception, e:
                print e
                print val, "may contain string, please check!"
                exit()
    
    s = 'Individual column: ' + id
    print s
    logfile_out.write(s + '\n')
    if id not in col_names:
        print id, 'is not in the data file, please check!'
        exit()
    if id not in class_vec:
        print 'The initial letter of', id, 'should be capital'
        exit()
    id_in_data_lst = list(data_df[id])
    
    s = 'Trait column: ' + ' '.join(np.array(trait, dtype=str))
    print s
    logfile_out.write(s + '\n')
    if max(trait) >= data_df.shape[1] or min(trait) < 0:
        print 'The index of trait is out of range!'
        exit()
    s = 'Trait column name: ' + ' '.join(list(col_names[trait]))
    print s
    logfile_out.write(s + '\n')
    if len(set(col_names[trait]) & set(class_vec)) != 0:
        print 'Phenotype values should not be defined as class variable, please check!'
        exit()
    
    s = '***Build the design matrix for fixed effect***'
    print s
    logfile_out.write(s + '\n')
    leg_fix = leg(np.array(tpoint), forder)
    leg_fix = np.array(leg_fix).reshape(forder + 1, 1, len(tpoint))
    leg_fix = np.concatenate([leg_fix] * data_df.shape[0], axis=1)
    xmat = leg_fix.transpose(1, 2, 0)
    xmat_null = np.concatenate(xmat, axis=0)
    y = np.array(data_df.iloc[:, trait]).reshape(data_df.shape[0]*len(trait), 1)
    eff, eff_var, sigma = longwas_lm(y, xmat_null)
    print 'the null variance:', sigma 
    
    snp_on_disk = Bed(bed_file, count_A1=False)
    if snp_lst is None:
        snp_lst = range(snp_on_disk.sid_count)
    else:
        try:
            snp_lst = np.array(snp_lst, dtype=int)
        except Exception, e:
            print e
            print 'The snp list value should be int'
            exit()
    snp_lst = list(snp_lst)
    if min(snp_lst) < 0 or max(snp_lst) >= snp_on_disk.sid_count:
        print 'The value in the snp list should be >=', 0, 'and <', snp_on_disk.sid_count
        exit()
    
    id_in_data_index = []
    for i in id_in_data_lst:
        id_in_data_index.append(list(snp_on_disk.iid[:, -1]).index(i))
    snp_data = snp_on_disk[id_in_data_index, snp_lst].read().val
    
    s = '***Start***'
    print s
    logfile_out.write(s + '\n')
    
    eff_vec = []
    chi_vec = []
    p_vec = []
    sigma_vec = []
    for i in range(snp_data.shape[1]):
        snp_fix = np.multiply(leg_fix, snp_data[:, i].reshape(1, snp_on_disk.iid_count, 1))
        snp_fix = snp_fix.transpose(1, 2, 0)
        snp_fix = np.concatenate(snp_fix, axis=0)
        xmat = np.concatenate((xmat_null, snp_fix), axis=1)
        eff, eff_var, sigma = longwas_lm(y, xmat)
        sigma_vec.append(sigma)
        # print sigma
        snp_eff = eff[-(forder+1):, -1]
        eff_vec.append(snp_eff)
        snp_eff_var = eff_var[-(forder+1):, -(forder+1):]
        chi_val = np.sum(reduce(np.dot, [snp_eff.T, np.linalg.inv(snp_eff_var), snp_eff]))
        p_val = chi2.sf(chi_val, forder+1)
        chi_vec.append(chi_val)
        p_vec.append(p_val)
    
    endtime = datetime.datetime.now()
    s = "Running time: " + str((endtime - starttime).seconds) + ' seconds'
    print s
    
    s = '***Output***'
    print s
    logfile_out.write(s + '\n')
    snp_info_file = bed_file + '.bim'
    snp_info = pd.read_csv(snp_info_file, sep='\s+', header=None)
    res_df = snp_info.iloc[snp_lst, [0, 1, 3, 4, 5]]
    res_df.columns = ['chro', 'snp_ID', 'pos', 'allele1', 'allele2']
    res_df.loc[:, 'order'] = snp_lst
    res_df = res_df.iloc[:, [5, 0, 1, 2, 3, 4]]
    res_df.loc[:, 'sigma'] = sigma_vec
    eff_vec = np.array(eff_vec)
    for i in range(eff_vec.shape[1]):
        col_ind = 'eff' + str(i)
        res_df.loc[:, col_ind] = eff_vec[:, i]
    res_df.loc[:, 'chi_val'] = chi_vec
    res_df.loc[:, 'p_val'] = p_vec
    
    out_file = prefix_outfile + '.res'
    try:
        res_df.to_csv(out_file, sep=' ', index=False)
    except Exception, e:
        print e
        print 'Fail to output the result!'
        exit()
    
    return res_df
