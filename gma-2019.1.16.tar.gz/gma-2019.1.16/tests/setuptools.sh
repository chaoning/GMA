python setup.py sdist --formats=gztar
python setup.py install
